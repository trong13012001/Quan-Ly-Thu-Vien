package com.example.pig;

public class User_Book {
    private int id_users;
    private String name_user;
    private int id;
    private String tieuDe;
    private int SoLuong;
    private String namXB;

    public User_Book() {
    }

    public User_Book(int id, String tieuDe,int SoLuong) {
        this.id = id;
        this.tieuDe = tieuDe;
        this.SoLuong = SoLuong;
    }

    public User_Book(int id, String tieuDe, int soLuong, String namXB) {
        this.id = id;
        this.tieuDe = tieuDe;
        SoLuong = soLuong;
        this.namXB = namXB;
    }

    public String getName_user() {
        return name_user;
    }

    public void setName_user(String name_user) {
        this.name_user = name_user;
    }

    public int getId_users() {
        return id_users;
    }

    public void setId_users(int id_users) {
        this.id_users = id_users;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTieuDe() {
        return tieuDe;
    }

    public void setTieuDe(String tieuDe) {
        this.tieuDe = tieuDe;
    }

    public int getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(int soLuong) {
        SoLuong = soLuong;
    }

    public String getNamXB() {
        return namXB;
    }

    public void setNamXB(String namXB) {
        this.namXB = namXB;
    }
}
