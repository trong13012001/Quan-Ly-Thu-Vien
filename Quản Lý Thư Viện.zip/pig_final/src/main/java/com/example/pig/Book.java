package com.example.pig;

public class Book {
    private int id;
    private String tieuDe;
    private int soLuong;
    private String namXB;

    public Book() {
    }


    public Book(int id,String tieuDe, int soLuong, String namXB) {
        this.id = id;
        this.tieuDe = tieuDe;
        this.soLuong = soLuong;
        this.namXB = namXB;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTieuDe() {
        return tieuDe;
    }

    public void setTieuDe(String tieuDe) {
        this.tieuDe = tieuDe;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public String getNamXB() {
        return namXB;
    }

    public void setNamXB(String namXB) {
        this.namXB = namXB;
    }
}
