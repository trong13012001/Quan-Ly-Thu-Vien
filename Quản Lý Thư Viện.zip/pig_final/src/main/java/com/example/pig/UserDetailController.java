package com.example.pig;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;

public class UserDetailController implements Initializable {

    @FXML
    private TableColumn<User_Book, String> DateTable;

    @FXML
    private TextField DateText;

    @FXML
    private TableColumn<User_Book, String> hoTenTable;

    @FXML
    private TableColumn<User_Book, Integer> idTable;

    @FXML
    private TableColumn<User_Book, Integer> iduserTable;

    @FXML
    private TableColumn<User_Book, String> namXBTable;

    @FXML
    private TableView<Book> listBookTable = new TableView<>();

    @FXML
    private TableView<User_Book> listUserBookTable = new TableView<>();
    @FXML
    private TableColumn<User_Book, String> soLuongTable;

    @FXML
    private TableColumn<User_Book, String> tieuDeTable;

    @FXML
    private Label maIDUser;

    @FXML
    private Label nameUser;

    @FXML
    private TextField soLuongText;

    @FXML
    private TableColumn<User_Book, Integer> SoLuongMuon;

    @FXML
    private TableColumn<User_Book, String> IDMUON;

    @FXML
    private TableColumn<User_Book, String> TIEUDE;

    ObservableList<Book> listBook = FXCollections.observableArrayList();
    ObservableList<User_Book> listUserBook = FXCollections.observableArrayList();
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        idTable.setCellValueFactory(new PropertyValueFactory<>("id"));
        tieuDeTable.setCellValueFactory(new PropertyValueFactory<>("tieuDe"));
        soLuongTable.setCellValueFactory(new PropertyValueFactory<>("soLuong"));
        namXBTable.setCellValueFactory(new PropertyValueFactory<>("namXB"));
        listBookTable.setItems(listBook);

        IDMUON.setCellValueFactory(new PropertyValueFactory<>("id"));
        TIEUDE.setCellValueFactory(new PropertyValueFactory<>("tieuDe"));
        SoLuongMuon.setCellValueFactory(new PropertyValueFactory<>("SoLuong"));
        listUserBookTable.setItems(listUserBook);
        try {
            Docfile();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void back(ActionEvent event) throws IOException {
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("User.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene);
        GhiFileSachMuon();
    }
    public void Borrow(ActionEvent event) throws IOException {
        Book selected = listBookTable.getSelectionModel().getSelectedItem();
        if(selected.getSoLuong() == 0){
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Hết Số Lượng Sách");
            alert.show();
        }
        else {
            if(listUserBook.size()==0){
                listUserBook.add(new User_Book(selected.getId(), selected.getTieuDe(), 1));
                selected.setSoLuong(selected.getSoLuong() - 1);
                listBook.set(listBook.indexOf(selected), selected);
            }
            else{
                for (User_Book user_book : listUserBook) {
                    if (selected.getId() == user_book.getId()) {
                        user_book.setSoLuong(user_book.getSoLuong() + 1);
                        System.out.println(user_book.getId());
                    } else {
                        listUserBook.add(new User_Book(selected.getId(), selected.getTieuDe(), 1));
                        selected.setSoLuong(selected.getSoLuong() - 1);
                        listBook.set(listBook.indexOf(selected), selected);
                    }
                }
            }
        }
        GhiFile();
    }

    public void Return() throws IOException {
        User_Book selected = listUserBookTable.getSelectionModel().getSelectedItem();
        listUserBook.remove(selected);
        for (Book book:listBook) {
            if(book.getId() == selected.getId()){
                book.setSoLuong(book.getSoLuong()+1);
                listBook.set(listBook.indexOf(book),book);
            }
        }
        GhiFile();

    }

    public void filter(){
        for (int i = 0; i < listBook.size(); i++) {
          if(listBook.get(i).getSoLuong() >= Integer.parseInt(soLuongText.getText())){

          }
        }
    }

    public void set(User user){
        maIDUser.setText(String.valueOf(user.getId_User()));
        nameUser.setText(String.valueOf(user.getName_User()));
    }
    public void Docfile() throws IOException {
        File fmh = new File("Book.txt");
        FileReader frmh = new FileReader(fmh);
        BufferedReader bufferedReaderMH = new BufferedReader(frmh);
        int j =1;
        String line = "";
        Book book = new Book(0,"NONE",0,"NONE");
        while ((line = bufferedReaderMH.readLine()) != null){
            if(j==1) {
                book.setId(Integer.parseInt(line));
                j++;
            } else if(j==2) {
                book.setTieuDe(line);
                j++;
            } else if(j==3) {
                book.setSoLuong(Integer.parseInt(line));
                j++;
            } else if(j==4) {
                book.setNamXB(line);
                listBook.add(new Book(book.getId(),book.getTieuDe(),book.getSoLuong(),book.getNamXB()));
                j=1;
            }
        }
        frmh.close();
        bufferedReaderMH.close();
    }
    public void GhiFile() throws IOException {
        File fkh = new File("Book.txt");
        FileWriter fwkh = new FileWriter(fkh);
        for (Book bk : listBook) {
            fwkh.write(String.valueOf(bk.getId()));
            fwkh.write("\n");
            fwkh.write(bk.getTieuDe());
            fwkh.write("\n");
            fwkh.write(bk.getSoLuong() +"");
            System.out.println(bk.getSoLuong());
            fwkh.write("\n");
            fwkh.write(bk.getNamXB());
            fwkh.write("\n");
        }
        fwkh.close();
    }
    // đọc file và lưu file của UserBook
    public void DocfileSachMuon() throws IOException {
        File fmh = new File("User_Book.txt");
        FileReader frmh = new FileReader(fmh);
        BufferedReader bufferedReaderMH = new BufferedReader(frmh);
        int j =1;
        String line = "";
        User_Book book = new User_Book(0,"NONE",0,"NONE");
        while ((line = bufferedReaderMH.readLine()) != null){
            if(j==1) {
                book.setId(Integer.parseInt(line));
                j++;
            } else if(j==2) {
                book.setTieuDe(line);
                j++;
            } else if(j==3) {
                book.setSoLuong(Integer.parseInt(line));
                j++;
            } else if(j==4) {
                book.setNamXB(line);
                listBook.add(new Book(book.getId(),book.getTieuDe(),book.getSoLuong(),book.getNamXB()));
                j=1;
            }
        }
        frmh.close();
        bufferedReaderMH.close();
    }
    public void GhiFileSachMuon() throws IOException {
        File fkh = new File("User_Book.txt");
        FileWriter fwkh = new FileWriter(fkh);
        for (User_Book bk : listUserBook) {
            fwkh.write(String.valueOf(bk.getId()));
            fwkh.write("\n");
            fwkh.write(bk.getTieuDe());
            fwkh.write("\n");
            fwkh.write(bk.getSoLuong() +"");
            System.out.println(bk.getSoLuong());
            fwkh.write("\n");
        }
        fwkh.close();
    }
}

