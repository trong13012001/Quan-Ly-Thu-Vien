package com.example.pig;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;

public class UserController implements Initializable {

    @FXML
    private TableColumn<User, String> hoTenTable;

    @FXML
    private TextField hoTenText;

    @FXML
    private TextField idUserText;

    @FXML
    private TableColumn<User, Integer> iduserTable;

    @FXML
    private TableView<User> userTable = new TableView<User>();

    ObservableList<User> tlUser = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        iduserTable.setCellValueFactory(new PropertyValueFactory<>("Id_User"));
        hoTenTable.setCellValueFactory(new PropertyValueFactory<>("Name_User"));
        userTable.setItems(tlUser);
        userTable.setOnMouseClicked(mouseEvent -> {
            User v= userTable.getSelectionModel().getSelectedItem();
            idUserText.setText(String.valueOf(v.getId_User()));
            hoTenText.setText(v.getName_User());
        });
        try {
            Docfile();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void AddUser(ActionEvent e) throws IOException {
        int iduser = 0;
        try {
            iduser = Integer.parseInt(idUserText.getText());
        }
        catch (NumberFormatException event){
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Lỗi");
            alert.setContentText("Mã sinh viên phải nhập số");
            alert.show();
        }
        User newUser = new User();
        newUser.setId_User(Integer.parseInt(idUserText.getText()));
        newUser.setName_User(hoTenText.getText());
        if( hoTenText.getText().equals("")){
            if(!tlUser.contains(newUser)) {
                idUserText.setText("");
                hoTenText.setText("");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Thông tin cảnh báo");
                alert.setContentText("Nhập sai!");
                alert.show();
            }
        }
        else {
            tlUser.add(newUser);
            idUserText.setText("");
            hoTenText.setText("");
        }
        GhiFile();
    }
    public void DeleteUser(ActionEvent e) throws IOException {
        User v= userTable.getSelectionModel().getSelectedItem();
        tlUser.remove(v);
        idUserText.setText("");
        hoTenText.setText("");
        GhiFile();
    }

    public void updateUser(ActionEvent event) throws IOException {
        User v= userTable.getSelectionModel().getSelectedItem();
        v.setId_User(Integer.parseInt(idUserText.getText()));
        v.setName_User(hoTenText.getText());
        tlUser.set(tlUser.indexOf(v),v);
        idUserText.setText("");
        hoTenText.setText("");
        GhiFile();
    }

    public void changSceneUserDetail(ActionEvent e) throws IOException {
        Stage stage = (Stage)((Node) e.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("UserDetail.fxml"));
        Parent userParent = loader.load();
        Scene scene = new Scene(userParent);
        UserDetailController controller = loader.getController();
        User selected = userTable.getSelectionModel().getSelectedItem();
        controller.set(selected);
        stage.setScene(scene);
    }

    @FXML
    public void BackUp(ActionEvent e) throws IOException {
        Stage stage = (Stage)((Node) e.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Menu.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene);
    }
    public void Docfile() throws IOException {
        File fmh = new File("User.txt");
        FileReader frmh = new FileReader(fmh);
        BufferedReader bufferedReaderMH = new BufferedReader(frmh);

        int j =1;
        String line = "";
        User user = new User(0,"NONE");
        while ((line = bufferedReaderMH.readLine()) != null){
            if(j==1) {
                user.setId_User(Integer.parseInt(line));
                j++;
            } else if(j==2) {
                user.setName_User(line);
                tlUser.add(new User(user.getId_User(),user.getName_User()));
                j=1;
            }
        }
        frmh.close();
        bufferedReaderMH.close();
    }
    // Lưu vào file
    public void GhiFile() throws IOException {
        File fkh = new File("User.txt");
        FileWriter fwkh = new FileWriter(fkh);
        for (User u : tlUser) {
            fwkh.write(String.valueOf(u.getId_User()));
            fwkh.write("\n");
            fwkh.write(u.getName_User());
            fwkh.write("\n");
            System.out.println("done");
        }
        fwkh.close();
    }
}