package com.example.pig;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;

public class BookController implements Initializable {
    @FXML
    private TableColumn<Book, Integer> idTable;

    @FXML
    private Label namXBBook;

    @FXML
    private TableColumn<Book,String> namXBTable;

    @FXML
    private TextField namXBText;

    @FXML
    private Text soLuongBook;

    @FXML
    private TableColumn<Book, String> soLuongTable;

    @FXML
    private TextField soLuongText;

    @FXML
    private TableView<Book> tableBook = new TableView<Book>();

    @FXML
    private Text tieuDeBook;

    @FXML
    private TableColumn<Book, String> tieuDeTable;

    @FXML
    private TextField tieuDeText;

    ObservableList<Book> tlBook = FXCollections.observableArrayList();
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        idTable.setCellValueFactory(new PropertyValueFactory<>("id"));
        tieuDeTable.setCellValueFactory(new PropertyValueFactory<>("tieuDe"));
        soLuongTable.setCellValueFactory(new PropertyValueFactory<>("soLuong"));
        namXBTable.setCellValueFactory(new PropertyValueFactory<>("namXB"));

        tableBook.setItems(tlBook);
        tableBook.setOnMouseClicked(mouseEvent -> {
            Book v= tableBook.getSelectionModel().getSelectedItem();
            tieuDeText.setText(v.getTieuDe());
            soLuongText.setText(String.valueOf(v.getSoLuong()));
            namXBText.setText(v.getNamXB());
        });
        try {
            Docfile();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void AddBook(ActionEvent event) throws IOException {
        int id = 1;
        if(tlBook.size() != 0){
            id = tlBook.get(tlBook.size()-1).getId()+1;
        }
        int SoLuong = 0;
        try {
             SoLuong = Integer.parseInt(soLuongText.getText());
        }
        catch(Exception e){
            SoLuong = 0;
        }
        Book v = new Book(id,tieuDeText.getText(),SoLuong,namXBText.getText());
        if(tieuDeText.getText().equals("") || namXBText.getText().equals("")){
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Thông tin cảnh báo");
            alert.setContentText("Nhập sai!");
            alert.show();
        }
        else {
            tlBook.add(v);
            tieuDeText.setText("");
            soLuongText.setText("");
            namXBText.setText("");
        }
        GhiFile();
    }
    @FXML
    public void DeleteBook(ActionEvent event) throws IOException {
        Book v= tableBook.getSelectionModel().getSelectedItem();
        tlBook.remove(v);
        tieuDeText.setText("");
        soLuongText.setText("");
        namXBText.setText("");
        GhiFile();
    }
    @FXML
    public void UpdateBook(ActionEvent event) throws IOException {
        Book v= tableBook.getSelectionModel().getSelectedItem();
        v.setTieuDe(tieuDeText.getText());
        v.setSoLuong(Integer.parseInt(soLuongText.getText()));
        v.setNamXB(namXBText.getText());
        tlBook.set(tlBook.indexOf(v),v);
        GhiFile();
    }
    @FXML
    public void BackUp(ActionEvent e) throws IOException {
        Stage stage = (Stage)((Node) e.getSource()).getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Menu.fxml"));
        Parent sampleParent = loader.load();
        Scene scene = new Scene(sampleParent);
        stage.setScene(scene);
    }
    // Đọc từ file Input
    public void Docfile() throws IOException {
        File fmh = new File("Book.txt");
        FileReader frmh = new FileReader(fmh);
        BufferedReader bufferedReaderMH = new BufferedReader(frmh);
        int j =1;
        String line = "";
        Book book = new Book(0,"NONE",0,"NONE");
        while ((line = bufferedReaderMH.readLine()) != null){
            if(j==1) {
                book.setId(Integer.parseInt(line));
                j++;
            } else if(j==2) {
                book.setTieuDe(line);
                j++;
            } else if(j==3) {
                book.setSoLuong(Integer.parseInt(line));
                j++;
            } else if(j==4) {
                book.setNamXB(line);
                tlBook.add(new Book(book.getId(),book.getTieuDe(),book.getSoLuong(),book.getNamXB()));
                j=1;
            }
        }
        frmh.close();
        bufferedReaderMH.close();
    }
    // Lưu vào file
    public void GhiFile() throws IOException {
        File fkh = new File("Book.txt");
        FileWriter fwkh = new FileWriter(fkh);
        for (Book bk : tlBook) {
            fwkh.write(String.valueOf(bk.getId()));
            fwkh.write("\n");
            fwkh.write(bk.getTieuDe());
            fwkh.write("\n");
            fwkh.write(bk.getSoLuong() +"");
            System.out.println(bk.getSoLuong());
            fwkh.write("\n");
            fwkh.write(bk.getNamXB());
            fwkh.write("\n");
        }
        fwkh.close();
    }

}
/*
if((char)i=='*'){
//                    System.out.println(cmt+"-"+ten+"-"+gt+"-"+ns);
                    BenhNhan v=new BenhNhan(cmt,ten,gt,Integer.parseInt(ns));
                    if(qlbn.add(v)==true){
                        listBenhNhan.add(v);
                    }

                    dem=0;ten=cmt=gt=ns="";
                } else if((char) i != '-'){
                    if(dem==0){
                        cmt+=""+(char) i;
                    }
                    if(dem==1){
                        ten+=""+(char) i;
                    }
                    if(dem==2){
                        gt+=""+(char) i;
                    }
                    if(dem==3){
                        ns+=""+(char) i;
                    }
                }
                else{
                    dem++;
                }
            }

            alert.setContentText("Đã đọc xong");
        } catch (FileNotFoundException e) {
            alert.setContentText("Gặp lỗi");
        } finally {
            bufferedInputStream.close();
            fileInputStream.close();
            alert.show();
        }
    }
 */