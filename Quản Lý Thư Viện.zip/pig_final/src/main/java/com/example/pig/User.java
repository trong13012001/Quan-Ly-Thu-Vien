package com.example.pig;

public class User implements Comparable<User> {
    private int Id_User;
    private String Name_User;


    public User() {
    }

    public User(int id_User, String name_User) {
        Id_User = id_User;
        Name_User = name_User;
    }

    public int getId_User() {
        return Id_User;
    }

    public void setId_User(int id_User) {
        Id_User = id_User;
    }

    public String getName_User() {
        return Name_User;
    }

    public void setName_User(String name_User) {
        Name_User = name_User;
    }


    @Override
    public int compareTo(User o) {
        return o.getId_User() - Id_User;
    }

}
