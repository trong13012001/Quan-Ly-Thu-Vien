module com.example.pig {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.pig to javafx.fxml;
    exports com.example.pig;
}